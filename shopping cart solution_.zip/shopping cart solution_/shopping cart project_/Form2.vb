﻿Imports System.Security
Imports System.Security.Cryptography

Public Class Form2

    Dim stateShippingCost() As Double = {5.0, 4.0, 3.0, 1.0, 1.0, 4.0, 2.0, 3.0, 2.0, 1.0}

    Dim stateNames() As String = {"New York", "New Jersey", "Pennsylvania", "Massachusetts", "Connecticut", "California", "Arizona", "Texas", "Florida", "Nevada"}

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lstfinalitemstobuy.Items.AddRange(Form1.lstcart.Items)
        lststatestoship.Items.AddRange(stateNames)

    End Sub



    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Dim subtotal As Double = 0.00
        Dim salestaxrate As Double = 0.04

        For Each Item As String In lstfinalitemstobuy.Items
            Dim separatestring() As String = Item.Split("  - $")
            Dim PRICE As Decimal = CDec(separatestring(3))
            subtotal += PRICE
            Dim salestaxamount As Double
            salestaxamount = subtotal * salestaxrate

            Dim shippingprice As Double


            If lststatestoship.SelectedIndex = 0 Then

                shippingprice = stateShippingCost(0)
                lblsubtotal.Text = subtotal.ToString("C2")
                lblsalestax.Text = salestaxamount.ToString("C2")
                lblshipping.Text = shippingprice.ToString("C2")
                lbltotalcost.Text = (subtotal + salestaxamount + shippingprice).ToString("C2")

            ElseIf lststatestoship.SelectedIndex = 1 Then
                shippingprice = stateShippingCost(1)
                lblsubtotal.Text = subtotal.ToString("C2")
                lblsalestax.Text = salestaxamount.ToString("C2")
                lblshipping.Text = shippingprice.ToString("C2")
                lbltotalcost.Text = (subtotal + salestaxamount + shippingprice).ToString("C2")

            ElseIf lststatestoship.SelectedIndex = 2 Then
                shippingprice = stateShippingCost(2)
                lblsubtotal.Text = subtotal.ToString("C2")
                lblsalestax.Text = salestaxamount.ToString("C2")
                lblshipping.Text = shippingprice.ToString("C2")
                lbltotalcost.Text = (subtotal + salestaxamount + shippingprice).ToString("C2")

            ElseIf lststatestoship.SelectedIndex = 3 Then
                shippingprice = stateShippingCost(3)
                lblsubtotal.Text = subtotal.ToString("C2")
                lblsalestax.Text = salestaxamount.ToString("C2")
                lblshipping.Text = shippingprice.ToString("C2")
                lbltotalcost.Text = (subtotal + salestaxamount + shippingprice).ToString("C2")

            ElseIf lststatestoship.SelectedIndex = 4 Then
                shippingprice = stateShippingCost(4)
                lblsubtotal.Text = subtotal.ToString("C2")
                lblsalestax.Text = salestaxamount.ToString("C2")
                lblshipping.Text = shippingprice.ToString("C2")
                lbltotalcost.Text = (subtotal + salestaxamount + shippingprice).ToString("C2")

            ElseIf lststatestoship.SelectedIndex = 5 Then
                shippingprice = stateShippingCost(5)
                lblsubtotal.Text = subtotal.ToString("C2")
                lblsalestax.Text = salestaxamount.ToString("C2")
                lblshipping.Text = shippingprice.ToString("C2")
                lbltotalcost.Text = (subtotal + salestaxamount + shippingprice).ToString("C2")

            ElseIf lststatestoship.SelectedIndex = 6 Then
                shippingprice = stateShippingCost(6)
                lblsubtotal.Text = subtotal.ToString("C2")
                lblsalestax.Text = salestaxamount.ToString("C2")
                lblshipping.Text = shippingprice.ToString("C2")
                lbltotalcost.Text = (subtotal + salestaxamount + shippingprice).ToString("C2")

            ElseIf lststatestoship.SelectedIndex = 7 Then
                shippingprice = stateShippingCost(7)
                lblsubtotal.Text = subtotal.ToString("C2")
                lblsalestax.Text = salestaxamount.ToString("C2")
                lblshipping.Text = shippingprice.ToString("C2")
                lbltotalcost.Text = (subtotal + salestaxamount + shippingprice).ToString("C2")

            ElseIf lststatestoship.SelectedIndex = 8 Then
                shippingprice = stateShippingCost(8)
                lblsubtotal.Text = subtotal.ToString("C2")
                lblsalestax.Text = salestaxamount.ToString("C2")
                lblshipping.Text = shippingprice.ToString("C2")
                lbltotalcost.Text = (subtotal + salestaxamount + shippingprice).ToString("C2")

            ElseIf lststatestoship.SelectedItem = "Nevada" Then
                shippingprice = 1.0
                lblsubtotal.Text = subtotal.ToString("C2")
                lblsalestax.Text = salestaxamount.ToString("C2")
                lblshipping.Text = shippingprice.ToString("C2")
                lbltotalcost.Text = (subtotal + salestaxamount + shippingprice).ToString("C2")


            End If


        Next

        Dim ranGen As New Random

        Dim intRanConfNum As Integer = ranGen.Next(111111, 999999)

        Dim result As DialogResult = MessageBox.Show("Thank you for shopping at DVD Shoppe! Your confirmation number is: " & intRanConfNum, "Would you like to continue shopping?", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If result = DialogResult.Yes Then
            Form1.Show()
            Me.Close()

        ElseIf result = DialogResult.No Then
            Me.Close()
            Form1.Close()

        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub lblsalestax_Click(sender As Object, e As EventArgs) Handles lblsalestax.Click

    End Sub
End Class