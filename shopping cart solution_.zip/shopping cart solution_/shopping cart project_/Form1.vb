﻿Public Class Form1

    Dim dvdPrices() As Double = {5.5, 6.25, 10.65, 8.5, 5.5, 10.65, 7.25, 12.75, 8.5, 12.75}
    Dim dvdNames() As String = {"Up", "Coco", "Frozen", "It", "Taken", "Goodfellas", "Grease", "Abduction", "Rocky", "Barbie"}
    Dim stateNames() As String = {"New York", "New Jersey", "Pennsylvania", "Massachusetts", "Connecticut", "California", "Arizona", "Texas", "Florida", "Nevada"}

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lstdvdnames.Items.AddRange(dvdNames)

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim index As Integer = lstdvdnames.SelectedIndex

        If index >= 0 And index < dvdNames.Length Then
            Dim name As String = dvdNames(index)
            Dim price As Double = dvdPrices(index)

            lstcart.Items.Add(name & "  - $" & price.ToString("F2"))

        End If


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lstcart.Items.Clear()
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        Dim index As Integer = lstdvdnames.SelectedIndex

        If index <> -1 Then
            Dim name As String = dvdNames(index)
            Dim price As Double = dvdPrices(index)

            Array.Resize(dvdNames, dvdNames.Length - 1)
            Array.Resize(dvdPrices, dvdPrices.Length - 1)

            lstcart.Items.RemoveAt(lstcart.SelectedIndex)





        End If


    End Sub

    Private Sub ToolStripMenuItem1_ItemClicked(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click


    End Sub

    Private Sub CheckoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CheckoutToolStripMenuItem.Click
        Form2.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub
End Class
